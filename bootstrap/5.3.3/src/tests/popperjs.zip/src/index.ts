export * from "@popperjs/core";
import DefaultImport from "typescript";
export default DefaultImport;