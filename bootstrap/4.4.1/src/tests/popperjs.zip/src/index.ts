import DefaultImport from "popper.js"
export {setup as webpmSetup} from './auto-generated'
// It may be the case that one of the two following line is not needed
export * from "popper.js"
export default DefaultImport

