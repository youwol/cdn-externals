import DefaultImport from 'popper.js'
export { setup as webpmSetup } from './auto-generated'
export * from 'popper.js'
export default DefaultImport
