import DefaultImport from 'jquery'
export { setup as webpmSetup } from './auto-generated'
export * from 'jquery'
export default DefaultImport
