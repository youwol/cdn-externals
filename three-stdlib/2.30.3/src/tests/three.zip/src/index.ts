import * as AllImports from "three";
export * from "three";

window["THREE_APIv0152"] = AllImports;
