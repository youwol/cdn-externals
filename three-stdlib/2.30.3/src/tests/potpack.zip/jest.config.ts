import { Config } from 'jest'

const jestConfig: Config = {
    // preset: '@youwol/jest-preset',
    // modulePathIgnorePatterns: [],
    transform: {
        '^.+\\.js$': 'jest-esm-transformer',
    },
    testEnvironment: 'node',
}
export default jestConfig
